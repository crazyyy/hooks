<?php

define('WPML_ICLM_URL', plugins_url('', dirname(__FILE__)));

