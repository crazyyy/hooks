<?php
delete_option('category_children');