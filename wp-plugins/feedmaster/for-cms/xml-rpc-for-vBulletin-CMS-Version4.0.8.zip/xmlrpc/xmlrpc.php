<?php
define('CHARSET', 'ISO-8859-1');
@error_reporting(0);
@ini_set('display_errors', false);
@ini_set('html_errors', false);
@ini_set ('error_reporting', 0);
//@error_reporting(E_ALL);
//@ini_set('display_errors', true);
//@ini_set('html_errors', true);
//@ini_set ('error_reporting', E_ALL);
session_start();
define('DIR', dirname(dirname(__FILE__)));
define('IMAGE_DIR', DIR . '/images/vbcms');
require_once (DIR . '/includes/config.php');
require_once('class_XML_RPC.php');

class VB_xmlrpc_server extends Server {
	var $errorStr = "Login/Password incorect";
	var $tablePrefix = '';
	var $home = '';
	var $userId = 1;
	var $contentType = 18;
	var $nodeParent = 1;
    function VB_xmlrpc_server() {
    	$this->Server(array(
    		'metaWeblog.login' => 'this:login',
    		'metaWeblog.newPost' => 'this:mw_newPost',
			'metaWeblog.getCategories' => 'this:mw_getCategories',
    		'metaWeblog.getSection' => 'this:mw_getSection',
			'metaWeblog.newMediaObject' => 'this:mw_newMediaObject',
			'demo.sayHello' => 'this:sayHello'
							)
		);
		
    }
    function init() {
    	global $config;
    	if (!function_exists('mysql_connect')) {
    		$this->errorStr = "mysql error: NOT MYSQL";
    		return false;
    	}
    	if (!mysql_connect($config['MasterServer']['servername'], $config['MasterServer']['username'], $config['MasterServer']['password'])) {
    		$this->errorStr = "mysql error: " . mysql_error();
    		return false;
    	}
    	if (!mysql_select_db($config['Database']['dbname'])) {
   			$this->errorStr = "mysql error: " . mysql_error();
    		return false;
    	}
    	$this->tablePrefix = $config['Database']['tableprefix'];
    	if (($res=mysql_query("SELECT value FROM {$this->tablePrefix}setting WHERE varname='bburl'"))===false) {
    		$this->errorStr = "Cannot select home url";
    		return false;
    	}
    	$row = mysql_fetch_assoc($res);
    	$this->home = trim($row['value']);
    	return true;
    }
    function login($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		if ($this->_login($user, $pass)) return true;
		else return $this->error(1, $this->errorStr);
    }
    function sayHello($args) {
        return 'Hello!' . var_export($args, true);
    }
    function mw_getCategories($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		$cats = array();
		$sql = "SELECT categoryid, parentcat, category, description FROM {$this->tablePrefix}cms_category";
		$res = mysql_query($sql);
		while (($row = mysql_fetch_assoc($res)) !== false) {
			$cat['categoryId'] = $row['categoryid'];
			$cat['parentId'] = ($row['parentcat']?parentcat:null);
			$cat['categoryName'] = $this->_encode($row['category']);
			$cat['description'] = $this->_encode(($row['description']?$row['description']:''));
			$cats[] = $cat;
		}
		return $cats;
	}
    function mw_getSection($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		$sections = array();
		$sql = "SELECT contenttypeid FROM {$this->tablePrefix}contenttype WHERE class='Section'";
		if (!($res = mysql_query($sql))) {
			$this->errorStr = "cannot select Section. SQL($sql) MySql error: ".mysql_error();
			return $this->error(9, $this->errorStr);
		}
		if (!($row = mysql_fetch_assoc($res))) {
			$this->errorStr = "cannot select Section. SQL($sql) MySql error: ".mysql_error();
			return $this->error(10, $this->errorStr);
		}
		$idSec = (int)$row['contenttypeid'];
		$sql = "SELECT n.nodeid, i.description, i.title FROM {$this->tablePrefix}cms_node AS n, {$this->tablePrefix}cms_nodeinfo AS i
WHERE n.contenttypeid=$idSec AND n.nodeid=i.nodeid";
		if (!($res = mysql_query($sql))) {
			$this->errorStr = "cannot select ALL Sections. SQL($sql) MySql error: ".mysql_error();
			return $this->error(11, $this->errorStr);
		}
		while (($row = mysql_fetch_assoc($res)) !== false) {
			$section['id'] = $row['nodeid'];
			$section['title'] = $this->_encode($row['title']);
			$section['description'] = $this->_encode(($row['description']?$row['description']:''));
			$sections[] = $section;
		}
		return $sections;
	}
	function mw_newPost($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		$content= $args[3];
		$publish= (int)$args[4];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		$error = 'NoError';
		$content['category'] = array();
		if (isset($content['nodeParent'])) $this->nodeParent = (int) $content['nodeParent'];
		$desk = $content['description'];
		preg_match_all('|<[\/\!]*?[^<>]*?[\/]?>|si', $desk, $htmltags);
		foreach($htmltags[0] as $key => $value) $desk = preg_replace("'".str_replace(array("'","|"), array("\'","\|"), quotemeta($value))."'", "(#)", $desk, 1);
		$desk = $this->_decode($desk);
		foreach($htmltags[0] as $key => $value) $desk = preg_replace('/\(#\)/si', $value, $desk, 1);
		$desk = mysql_escape_string($desk);
		//$url = mysql_escape_string($this->_decode($content['title']));
		$title=mysql_escape_string($this->_decode($content['title']));
		$url = $this->translit($content['title']);
		$data = (int)$content['dateCreated'];
		$commentsEnabled = (int)$content['commentsEnabled'];
		$sql = "SELECT noderight FROM {$this->tablePrefix}cms_node WHERE nodeid={$this->nodeParent}";
		if (($res=mysql_query($sql))===false) {
			$this->errorStr = "cannot select noderight.SQL($sql) MySql error: ".mysql_error();
			return $this->error(8, $this->errorStr);
		}
		$row = mysql_fetch_assoc($res);
		$nodeR = $row['noderight'] + 2;
		$nodeL = $nodeR - 1;
		mysql_query("UPDATE {$this->tablePrefix}cms_node SET noderight=noderight+2 WHERE nodeid={$this->nodeParent}");
		$res = mysql_query("INSERT INTO {$this->tablePrefix}cms_article
(contentid, pagetext, threadid, blogid, posttitle, postauthor, poststarter, blogpostid, postid, post_posted, post_started, previewtext, previewimage, imagewidth, imageheight, previewvideo, htmlstate) VALUES
(NULL, 		'{$desk}', NULL, 	NULL, 	NULL, 		NULL, 		NULL, 		NULL, 		NULL, 		NULL,	 	NULL, 			NULL, 		'', 		0, 			0, 			'', 		'on_nl2br')");
		if (!$res || !mysql_affected_rows()) {
			$this->errorStr = "cannot insert article. MySql error: ".mysql_error();
			return $this->error(1, $this->errorStr);
		}
		$contentId = mysql_insert_id();
		$sql = "INSERT INTO {$this->tablePrefix}cms_node
(nodeid, nodeleft, noderight, parentnode, contenttypeid, 	contentid, 			url, 	styleid, layoutid, userid, 		publishdate, setpublish, issection, onhomepage, permissionsfrom, lastupdated, publicpreview, auto_displayorder, comments_enabled, new, showtitle, showuser, showpreviewonly, showupdated, showviewcount, showpublishdate, settingsforboth, includechildren, showall, editshowchildren, showrating, hidden, shownav, nosearch) VALUES
(NULL,{$nodeL},{$nodeR},'{$this->nodeParent}',{$this->contentType}, '{$contentId}', '{$url}', NULL, NULL, 	{$this->userId}, {$data}, {$publish}, 	'0', 		'0', 		'1', 			{$data}, 		'1', 			'0', 			{$commentsEnabled}, '0', '1', 		'1', 		'1', 			'0', 		'0', 			'1', 			'1', 			'1', 			'1', 		'0', 			'0', 		'0', 	'0', 	'0')";
		if (!mysql_query($sql) || !mysql_affected_rows()) {
			$this->errorStr = "cannot insert node. SQL($sql). MySql error: ".mysql_error();
			return $this->error(1, $this->errorStr);
		}
		$nodeId = mysql_insert_id();
		$sql = "INSERT INTO {$this->tablePrefix}cms_nodeinfo
(nodeid, description, title, html_title, viewcount, creationdate, workflowdate, workflowstatus, workflowcheckedout, workflowpending, workflowlevelid, associatedthreadid, keywords, ratingnum, ratingtotal, rating) VALUES
({$nodeId},  '{$title}','{$title}','{$title}', '0', 	{$data}, 		NULL, 		NULL, 			NULL, 				NULL, 				'0', 			'0', 			 '{$title}', '0', 		'0', 		'0');";
		if (!mysql_query($sql) || !mysql_affected_rows()) {
			$this->errorStr = "cannot insert nodeinfo. MySql error: ".mysql_error();
			return $this->error(1, $this->errorStr);
		}
		if (is_array($content['categories'])){
			$names = '';
			foreach($content['categories'] as $cat) {
				$names .= "'". $this->_decode($cat) ."', ";
			}
			$names = rtrim($names, ', ');
			$sql = "SELECT categoryid as id FROM {$this->tablePrefix}cms_category WHERE category IN ({$names})";
			if (!$res = mysql_query($sql)) $error = "cannot select category.SQL($sql). MySql error: ".mysql_error();
			else {
	 			while (($row = mysql_fetch_assoc($res)) !== false) {
	 				mysql_query("INSERT INTO {$this->tablePrefix}cms_nodecategory
	 					(categoryid, nodeid) VALUES ({$row['id']}, {$nodeId})");
				}
			}
		}
		if (is_array($content['mt_keywords'])){
			$tags = '';
			foreach($content['mt_keywords'] as $tag) {
				$tag = trim($this->_decode($tag));
				mysql_query("INSERT IGNORE INTO {$this->tablePrefix}tag (tagid, tagtext, dateline, canonicaltagid) VALUES
																 (NULL, '{$tag}', '{$data}', '0')");
				$tags .= "'$tag', ";
			}
			$tags = rtrim($tags, ', ');
			$sql = "SELECT tagid AS id FROM {$this->tablePrefix}tag WHERE tagtext IN ($tags)";
			if (!$res = mysql_query($sql)) $error = "cannot select category.SQL($sql). MySql error: ".mysql_error();
			else {
			 	while (($row = mysql_fetch_assoc($res)) !== false) {
 					mysql_query("INSERT IGNORE INTO {$this->tablePrefix}tagcontent
 					(tagid, contenttypeid, contentid, userid, dateline) VALUES
 					({$row['id']}, {$this->contentType}, {$contentId}, {$this->userId}, {$data})");
				}
			}
		}
		return array('Error'=>$error, 'contentId'=>$contentId, 'nodeId'=>$nodeId, 'url'=>"{$this->home}/content.php?{$nodeId}-{$url}");
	}
	function mw_newMediaObject($args) {
		$blogId = (int) $args[0];
		$user  = $args[1];
		$pass  = $args[2];
		$data  = $args[3];
		$type = $data['type'];
		if ( !$user = $this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		if(($name=$this->saveFile($data['name'], $data['bits']))===false) return $this->error(3, $this->errorStr);
		return array(
					'file' => basename($name),
					'url' => $this->home.$name,
					'type' => $data['type']
		);
	}
	function saveFile($name, $data) {
		$full = IMAGE_DIR."/$name";
		if (!@file_put_contents($full, $data)) return false;
		return substr($full, strlen(DIR));
	}
	function _login($user, $pass) {
		if (!$this->init()) return false;
		$user = trim($user);
		$sql = "SELECT userid, usergroupid, password, salt FROM {$this->tablePrefix}user WHERE username = '{$user}'";
		if (($res = mysql_query($sql)) === false) {
    		$this->errorStr = "mysql error: ".mysql_error();
    		return false;
		}
		if (!mysql_num_rows($res)) {
    		return false;
		}
		$row = mysql_fetch_assoc($res);
		$this->userId = $row['userid'];
		$pass = md5(	md5(trim($pass)) . trim($row['salt'])	);
		if ($pass == $row['password']) return true;
		return false;
	}
	function _encode($text){
		if (strtoupper(CHARSET) == 'ISO-8859-1') {
			return html_entity_decode($text, ENT_NOQUOTES,'UTF-8');
		} else
		if (strtoupper(CHARSET) != 'UTF-8'){
			return iconv(CHARSET, 'UTF-8', $text);
		}
		return $text;
	}
	function _decode($text){
		if (strtoupper(CHARSET) == 'ISO-8859-1') {
			$text = iconv('utf-8', 'cp1251//IGNORE', $text);
			$r = htmlentities($text, ENT_NOQUOTES, 'cp1251');
			//file_put_contents(__FILE__.'.log', $text."\n\n================\n\n".$r.'======================', FILE_APPEND);
			return $r;
		} elseif (strtoupper(CHARSET) != 'UTF-8'){
			return iconv('UTF-8', CHARSET , $text);
		}
		return $text;
	}
	private function translit($st) {
		$st = strtr($st, array("А" => "A", "Б" => "B", "В" => "V", "Г" => "G", "Д" => "D", "Е" => "E", "Ж" => "J", "З" => "Z", "И" => "I", "Й" => "Y", "К" => "K", "Л" => "L", "М" => "M", "Н" => "N", "О" => "O", "П" => "P", "Р" => "R", "С" => "S", "Т" => "T", "У" => "U", "Ф" => "F", "Х" => "H", "Ц" => "TS", "Ч" => "CH", "Ш" => "SH", "Щ" => "SCH", "Ъ" => "", "Ы" => "YI", "Ь" => "", "Э" => "E", "Ю" => "YU", "Я" => "YA", "а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "е" => "e", "ж" => "j", "з" => "z", "и" => "i", "й" => "y", "к" => "k", "л" => "l", "м" => "m", "н" => "n", "о" => "o", "п" => "p", "р" => "r", "с" => "s", "т" => "t", "у" => "u", "ф" => "f", "х" => "h", "ц" => "ts", "ч" => "ch", "ш" => "sh", "щ" => "sch", "ъ" => "y", "ы" => "yi", "ь" => "", "э" => "e", "ю" => "yu", "я" => "ya"));
		$st = preg_replace('|[^\w\d ]|is', '', $st);
		$st = preg_replace('|\s+|is', '-', $st);
		return $st;
	}
}

$server = new VB_xmlrpc_server();
