===============================================================================
 English
===============================================================================
Title:   xmlrpc-server for Joomla! v.1.0.x
Version: 1.0a
Author:  Alexander Solovyov (a.k.a. dex_stern)
License: GNU / GPL (read license.txt)

Description:
This component enables usage of xmlrpc-mambots for Joomla! v.1.0.x in the same way it does Joomla v.1.5

Requirements: 
-------------
Joomla v.1.0.x

Installation:
-------------
1. Extract contents of the joom_xmlrpc_bundle.zip onto your local drive;
2. Open Joomla! Administrative area
3. Install component - com_xmlrpc.zip:
   n.b.: in case your webserver-process has no permissions for mkdir
         in the root dir - manually create in the site root directory 'xmlrpc'
         and move there all contents
         of [siteroot_dir]/administrator/components/com_xmlrpc/xmlrpc/
4. Install MT xmlrpc-mambot: bot_jmt_api.zip
5. Install rsd-mambot: bot_rsd.zip
6. Publish installed mambots
7. For jMT_API mambot set at least 'Database encoding' parameter 
   (which is set to 'utf-8' by default) 

Now you can connect to the xmlrpc-server by any of xmlrpc-clients 
   (I prefer Zoundry(tm) www.zoundry.com) using parameters:
   - xmlrpc-API: MovableType (MT)
   - API URL (in case RSD doesn't work): http://[your_site]/xmlrpc/index.php
   - user account: any of your existing Joomla!-user account data.
Please, remember that at the moment it is an alpha version and there may be a lot of bugs, so it is still "unstable and should not be used in a production environment or any place where your data is important".

Known issues:
------------
- non-UTF clients (such as wBloggar etc.) not supported
- extension doesn't work on some of free hostings with mandatory AD-insertion
  (xml-paket corruption)
- jMT API doesn't check Joomla!-user access rights for single
  section or category

===============================================================================
 Deutsch
===============================================================================
Titel:   xmlrpc-server für Joomla! v.1.0.x
Version: 1.0a
Autor:  Alexander Solovyov (a.k.a. dex_stern)
Lizenz:  GNU / GPL (license.txt lesen)

Beschreibung:
-------------

Voraussetzungen: 
----------------

Installation:
-------------


===============================================================================
 Russian
===============================================================================