<?php
define('CHARSET', 'CP1251');
@error_reporting(0);
@ini_set('display_errors', false);
@ini_set('html_errors', false);
@ini_set ('error_reporting', 0);
//	@error_reporting(E_ALL);
//	@ini_set('display_errors', true);
//	@ini_set('html_errors', true);
//	@ini_set ('error_reporting', E_ALL);
define('VALID_CMS', 1);
define('DIR', dirname(__FILE__));
define('IMAGE_DIR', DIR . '/images');
$contentTpl = 'com_content_read.tpl';
$categoryTpl = 'com_content_view.tpl';
require_once (DIR . '/includes/config.inc.php');
require_once('class_XML_RPC.php');

class Ins_xmlrpc_server extends Server {
	var $errorStr = "Login/Password incorect";
	var $tablePrefix = '';
	var $home = '';
	var $userId = 1;
	var $c = array();
    function Ins_xmlrpc_server() {
    	global $_CFG;
    	$this->c = $_CFG;
    	$this->Server(array(
    		'metaWeblog.login' => 'this:login',
    		'metaWeblog.newPost' => 'this:mw_newPost',
			'metaWeblog.getCategories' => 'this:mw_getCategories',
    		'metaWeblog.getSection' => 'this:mw_getSection',
			'metaWeblog.newMediaObject' => 'this:mw_newMediaObject',
			'demo.sayHello' => 'this:sayHello'
							)
		);
    }
    function init() {
    	global $config;
    	if (!function_exists('mysql_connect')) {
    		$this->errorStr = "mysql error: NOT MYSQL";
    		return false;
    	}
    	if (!mysql_connect($this->c['db_host'], $this->c['db_user'], $this->c['db_pass'])) {
    		$this->errorStr = "mysql error: " . mysql_error();
    		return false;
    	}
    	if (!mysql_select_db($this->c['db_base'])) {
   			$this->errorStr = "mysql error: " . mysql_error();
    		return false;
    	}
    	$ch = strtolower(CHARSET);
    	if (!mysql_query("SET character_set_results = '$ch', character_set_client = '$ch', character_set_connection = '$ch', character_set_database = '$ch', character_set_server = '$ch'")) {
   			$this->errorStr = "mysql error: " . mysql_error();
    		return false;
       	}
    	$this->tablePrefix = $this->c['db_prefix'];
    	$this->home = 'http://' . $_SERVER['HTTP_HOST'];
    	return true;
    }
    function login($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		if ($this->_login($user, $pass)) return true;
		else return $this->error(1, $this->errorStr);
    }
    function sayHello($args) {
        return 'Hello!' . var_export($args, true);
    }
    function mw_getCategories($args) {
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		$cats = array();
		$sql = "SELECT `id`, `parent_id`, `title`, `description` FROM `{$this->tablePrefix}_category`";
		$res = mysql_query($sql);
		while (($row = mysql_fetch_assoc($res)) !== false) {
			$cat['categoryId'] = $row['id'];
			$cat['parentId'] = $row['parent_id'];
			$cat['categoryName'] = $this->_encode($row['title']);
			$cat['description'] = $this->_encode($row['description']);
			$cats[] = $cat;
		}
		return $cats;
	}
	function mw_newPost($args) {
		global $contentTpl;
		$blogId = (int) $args[0];
		$user   = $args[1];
		$pass   = $args[2];
		$content= $args[3];
		$publish= (int)$args[4];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		$error = 'NoError';
		$desk = $content['description'];
		preg_match_all('|<[\/\!]*?[^<>]*?[\/]?>|si', $desk, $htmltags);
		foreach($htmltags[0] as $key => $value) $desk = preg_replace("'".str_replace(array("'","|"), array("\'","\|"), quotemeta($value))."'", "(#)", $desk, 1);
		$desk = $this->_decode($desk);
		foreach($htmltags[0] as $key => $value) $desk = preg_replace('/\(#\)/si', $value, $desk, 1);
		$desk = mysql_escape_string($desk);
		//$url = mysql_escape_string($this->_decode($content['title']));
		$fullDesk = $content['full_description'];
		preg_match_all('|<[\/\!]*?[^<>]*?[\/]?>|si', $fullDesk, $htmltags);
		foreach($htmltags[0] as $key => $value) $fullDesk = preg_replace("'".str_replace(array("'","|"), array("\'","\|"), quotemeta($value))."'", "(#)", $fullDesk, 1);
		$fullDesk = $this->_decode($fullDesk);
		foreach($htmltags[0] as $key => $value) $fullDesk = preg_replace('/\(#\)/si', $value, $fullDesk, 1);
		$fullDesk = mysql_escape_string($fullDesk);
		
		$title=mysql_escape_string($this->_decode($content['title']));
		$url = $this->translit($content['title']);
		$data = date('Y-m-d H:i:s', (int)$content['dateCreated']);
		$comm = (int)$content['commentsEnabled'];
		$catId = $content['categories'];
		if(is_array($catId)) $catId = $catId[0];
		$keys = '';
		$tags = array();
		if (is_array($content['mt_keywords'])) foreach($content['mt_keywords'] as $key) {
			$tmp = trim($this->_decode($key));
			$tags[] = $tmp;
			$keys .= $tmp . ', ';
		}
		$keys = mysql_escape_string(substr($keys, 0, -2));
		$sql = "INSERT INTO `{$this->tablePrefix}_content`
(`id`, `category_id`, `user_id`, `pubdate`, `enddate`, `is_end`,`title`, `description`,`content`,`published`, `hits`,`meta_desc`,`meta_keys`,`showtitle`,`showdate`,`showlatest`,`showpath`,`ordering`,`comments`,`is_arhive`,`seolink`, `canrate`,`pagetitle`, `url`, `tpl`) VALUES
(NULL, '$catId', '{$this->userId}','{$data}','2012-12-12', '0', '{$title}', '{$desk}', '{$fullDesk}', '$publish',	'0', '', 		'$keys', 		'1', 		'1', 		'1', 		'1', 		'1', 	'$comm', 	'0', 		'{$url}', '1', 		'', 		'', 	'$contentTpl');";
		if (!mysql_query($sql) || !mysql_affected_rows()) {
			$this->errorStr = "cannot insert article. MySql error: ".mysql_error();
			return $this->error(1, $this->errorStr);
		}
		$contentId = mysql_insert_id();
		// tags
		foreach($tags as $tag) {
			mysql_query("INSERT INTO `{$this->tablePrefix}_tags`(id, tag, target, item_id) VALUES (
															NULL, '$tag', 'content', '$contentId')");
		}
		
		return array('Error'=>$error, 'contentId'=>$contentId, 'url'=>"{$this->home}/{$url}.html");
	}
	function mw_newMediaObject($args) {
		$blogId = (int) $args[0];
		$user  = $args[1];
		$pass  = $args[2];
		$data  = $args[3];
		$type = $data['type'];
		if (!$this->_login($user, $pass)) return $this->error(1, $this->errorStr);
		if(($name=$this->saveFile($data['name'], $data['bits']))===false) return $this->error(3, 'Не могу сохранить файл');
		return array(
					'file' => basename($name),
					'url' => $this->home.$name,
					'type' => $data['type']
		);
	}
	function saveFile($name, $data) {
		$full = IMAGE_DIR."/$name";
		if (!@file_put_contents($full, $data)) return false;
		return substr($full, strlen(DIR));
	}
	function _login($user, $pass) {
		if (!$this->init()) return false;
		$user = trim($user);
		$sql = "SELECT `id` FROM `{$this->tablePrefix}_users` WHERE `login`='$user' AND `password`=md5('$pass')";
		if (($res = mysql_query($sql)) === false) {
    		$this->errorStr = "mysql error: ".mysql_error();
    		return false;
		}
		if (!mysql_num_rows($res)) return false;
		$row = mysql_fetch_assoc($res);
		$this->userId = $row['id'];
		return true;
	}
	function _encode($text){
		if (strtoupper(CHARSET) == 'ISO-8859-1') {
			return html_entity_decode($text, ENT_NOQUOTES,'UTF-8');
		} else
		if (strtoupper(CHARSET) != 'UTF-8'){
			return iconv(CHARSET, 'UTF-8', $text);
		}
		return $text;
	}
	function _decode($text){
		if (strtoupper(CHARSET) == 'ISO-8859-1') {
			$text = iconv('utf-8', 'cp1251//IGNORE', $text);
			$r = htmlentities($text, ENT_NOQUOTES, 'cp1251');
			//file_put_contents(__FILE__.'.log', $text."\n\n================\n\n".$r.'======================', FILE_APPEND);
			return $r;
		} elseif (strtoupper(CHARSET) != 'UTF-8'){
			return iconv('UTF-8', CHARSET , $text);
		}
		return $text;
	}
	function _getCatId($category) {
		global $categoryTpl;
		$category = mysql_escape_string($category);
		$sql = "SELECT `id` FROM `{$this->tablePrefix}_category` WHERE `title` = '$category'";
		if (($res = mysql_query($sql)) === false) {
    		$this->errorStr = "mysql error: select cat id: ".mysql_error();
    		return 1;
		}
		if (mysql_num_rows($res)) {
			$row = mysql_fetch_assoc($res);
			return $row['id'];
		} else {
			mysql_query("INSERT INTO `{$this->tablePrefix}_category`
(id,parent_id,title, description, published, showdate, showcomm, orderby, orderto, modgrp_id, NSLeft, NSRight, NSLevel, NSDiffer, NSIgnore, ordering, maxcols, showtags, showrss, showdesc, is_public, photoalbum, seolink, url, tpl, cost) VALUES
(NULL, '1', '$category', '', 		'0', 		'1', 	'1', 	'pubdate', 'asc', 	'0', 		'0', 	'0', 	'1', 	'', 		'0', 	'1', 		'1', 	'1', 		'1', 	'1', 		'1', 	'1', 		'', 	'', '$categoryTpl', '')");
			return mysql_insert_id();
		}
		
	}
	private function translit($st) {
		$st = strtr($st, array("А" => "A", "Б" => "B", "В" => "V", "Г" => "G", "Д" => "D", "Е" => "E", "Ж" => "J", "З" => "Z", "И" => "I", "Й" => "Y", "К" => "K", "Л" => "L", "М" => "M", "Н" => "N", "О" => "O", "П" => "P", "Р" => "R", "С" => "S", "Т" => "T", "У" => "U", "Ф" => "F", "Х" => "H", "Ц" => "TS", "Ч" => "CH", "Ш" => "SH", "Щ" => "SCH", "Ъ" => "", "Ы" => "YI", "Ь" => "", "Э" => "E", "Ю" => "YU", "Я" => "YA", "а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "е" => "e", "ж" => "j", "з" => "z", "и" => "i", "й" => "y", "к" => "k", "л" => "l", "м" => "m", "н" => "n", "о" => "o", "п" => "p", "р" => "r", "с" => "s", "т" => "t", "у" => "u", "ф" => "f", "х" => "h", "ц" => "ts", "ч" => "ch", "ш" => "sh", "щ" => "sch", "ъ" => "y", "ы" => "yi", "ь" => "", "э" => "e", "ю" => "yu", "я" => "ya"));
		$st = preg_replace('|[^\w\d ]|is', '', $st);
		$st = preg_replace('|\s+|is', '-', $st);
		return $st;
	}
}

$server = new Ins_xmlrpc_server();
