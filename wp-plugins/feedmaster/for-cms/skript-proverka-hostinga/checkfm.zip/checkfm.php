<?php
define('OK', 'Настройки и конфигурация сервера соответствует требованиям FeedMaster!');
define('ERR', 'К сожалению настройки и конфигурация сервера не соответствует требования FeedMaster');
function check() {
	$result = true;
	echo "Версия PHP > 5.2.0... ";
	flush();
	$php_version = substr(phpversion(), 0, 5);
	if (version_compare($php_version, '5.2.0', '<')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка расширение DOM... ";
	flush();
	if (!class_exists('DOMDocument')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка расширение fsockopen... ";
	flush();
	if (!function_exists('fsockopen')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка расширение iconv... ";
	flush();
	if (!function_exists('iconv')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка расширение mb_substr... ";
	flush();
	if (!function_exists('mb_substr')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка расширение CURL... ";
	flush();
	if (!function_exists('curl_init')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();

	echo "Поддержка модуля ionCube Loader... ";
	flush();
	if (!extension_loaded('ionCube Loader')) {
		$result = false;
		echo "<font color='#CC0000'><b>Ошибка!</b></font><br />";
	} else {
		echo "<b>OK</b><br />";
	}
	flush();
	
	echo "<br /><br />";

	if ($result) echo OK;
	else echo ERR;
}
check();