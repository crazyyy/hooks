<?php
$enable_xmlrpc = TRUE;
$allow_comm = TRUE;
$allow_rating = TRUE;
@session_start ();
@error_reporting ( E_ALL ^ E_NOTICE );
@ini_set ( 'display_errors', true );
@ini_set ( 'html_errors', false );
@ini_set ( 'error_reporting', E_ALL ^ E_NOTICE );
define ( 'DATALIFEENGINE', true );
$member_id = FALSE;
$is_logged = FALSE;
$gmt_offset = 7;
session_start();
$_SESSION['dle_log'] = 0;
define ( 'ROOT_DIR', dirname ( __FILE__ ) );
define ( 'ENGINE_DIR', ROOT_DIR . '/engine' );
require_once (ENGINE_DIR . '/inc/include/init.php');
require_once('IXR_Library.inc.php');
if ( isset( $_GET['rsd'] ) ) { // http://archipelago.phrasewise.com/rsd
header('Content-Type: text/xml; charset=utf-8', true);
?>
<?php echo '<?xml version="1.0" encoding="utf-8"?'.'>'; ?>
<rsd version="1.0" xmlns="http://archipelago.phrasewise.com/rsd">
  <service>
    <engineName>DataLife Engine</engineName>
    <engineLink>http://dle-news.ru/</engineLink>
    <homePageLink></homePageLink>
    <apis>
      <api name="MetaWeblog" blogID="1" preferred="true" apiLink="<?php echo $config['http_home_url'] . 'xmlrpc.php' ?>" />
    </apis>
  </service>
</rsd>
<?php
exit;
}
function __($text){
	return $text;
}
class dle_xmlrpc_server extends IXR_Server {
    function dle_xmlrpc_server() {
		$this->methods = array(
			'blogger.getUsersBlogs' => 'this:blogger_getUsersBlogs',
			// MetaWeblog API (with MT extensions to structs)
			'metaWeblog.newPost' => 'this:mw_newPost',
			'metaWeblog.getCategories' => 'this:mw_getCategories',
			'metaWeblog.newMediaObject' => 'this:mw_newMediaObject',
			'metaWeblog.editPost' => 'this:mw_editPost',
			'demo.sayHello' => 'this:sayHello',
			'demo.addTwoNumbers' => 'this:addTwoNumbers'
		);
		$this->IXR_Server($this->methods);
    }
    function sayHello($args) {
        return 'Hello!';
    }
    function addTwoNumbers($args) {
        $number1 = $args[0];
        $number2 = $args[1];
        return $number1 + $number2;
    }
    function blogger_getUsersBlogs($args){
		global $config;
		$username = $args[1];
		$password  = $args[2];
    	if ( !$user = $this->_login($username, $password) ) {
			return $this->error;
		}
		$struct = array(
			'isAdmin'  => 1,
			'url'      => $config['http_home_url'],
			'blogid'   => '1',
			'blogName' => $this->_encode($config['home_title']),
			'xmlrpc'   => $config['http_home_url'] . 'xmlrpc.php'
		);
		return array($struct);
    }
	function mw_getCategories($args) {
		$blog_ID     = (int) $args[0];
		$username  = $args[1];
		$password   = $args[2];
		if ( !$user = $this->_login($username, $password) ) {
			return $this->error;
		}
		$categories_struct = array();
		global $cat_info;
		global $config;
		if ( $cat_info ) {
			foreach ( $cat_info as $cat ) {
				$struct['categoryId'] = $cat['id'];
				$struct['parentId'] = $cat['parentid'];
				$struct['description'] = $this->_encode($cat['name']);
				$struct['categoryDescription'] = $this->_encode($cat['descr']);
				$struct['categoryName'] = $this->_encode($cat['name']);
				$url_page = $config['http_home_url'] . get_url($cat['id']);
				$struct['htmlUrl'] = $url_page;
				if ($config['allow_alt_url'] == "yes") {
					$rss_url = $url_page . "/" . "rss.xml";
				}
				else {
					$rss_url = $config['http_home_url'] . "engine/rss.php?do=cat&category=" . $cat['alt_name'];
				}
				$struct['rssUrl'] = $rss_url;
				$categories_struct[] = $struct;
			}
		}
		return $categories_struct;
	}
	function _encode($text){
		global $config;
		if (strtoupper($config['charset']) != 'UTF-8'){
			$result = iconv($config['charset'], 'UTF-8', $text);
			return $result;
		}
		return $text;
	}
	function _decode($text){
		global $config;
		if (strtoupper($config['charset']) != 'UTF-8'){
			$result = iconv('UTF-8', $config['charset'] , $text);
			return $result;
		}
		return $text;
	}
	function _login($username, $password) {
		global $enable_xmlrpc;
		if ( !$enable_xmlrpc ) {
			$this->error = new IXR_Error( 405, sprintf( __( 'XML-RPC services are disabled on this blog.  An admin user can enable them in file %s'),  "xmlrpc.php" ) );
			return false;
		}
		$user = check_login($username, md5($password), true);
		if (!$user) {
			$this->error = new IXR_Error(403, __('Bad login/pass combination.'));
			return false;
		}
		return $user;
	}
	function mw_newPost($args) {
		global $db;
		global $gmt_offset;
		$blog_ID     = (int) $args[0]; // we will support this in the near future
		$username  = $args[1];
		$password   = $args[2];
		$content_struct = $args[3];
		$publish     = $args[4];
		/*$fp = fopen('xmlrpc_log.txt', "w+");
		foreach($content_struct as $item => $val){
			if (is_array($val)) $val = implode(",", $val);
			fwrite($fp, $item . ": " . $val . "\r\n");
		}
		fclose($fp);*/
		if ( !$user = $this->_login($username, $password) ) {
			return $this->error;
		}
		if (is_array($content_struct['categories'])){
			foreach($content_struct['categories'] as $category){
				$category_name = $this->_decode($category);
				#get category id
				$db->query( "SELECT * FROM " . PREFIX . "_category WHERE (name='$category_name')" );
 				while ( $row = $db->get_row() ) {
 					$category_id = $row['id'];
 				}
				$content_struct['category'][] = $category_id;
			}
		}
		$content_struct['approve'] = $publish;
		$content_struct['title'] = $this->_decode($content_struct['title']);
		$content_struct['short_story'] = $this->_decode($content_struct['description']);
		$content_struct['tags'] = $this->_decode($content_struct['mt_keywords']);
		$content_struct['allow_comm'] = $content_struct['mt_allow_comments'];
		//$content_struct['mt_allow_pings'] = $content_struct['allow_comm'];
		$content_struct['allow_main'] = 1;
		//XXX
		if (isset($content_struct['full_story'])) {
			$content_struct['full_story'] = $this->_decode($content_struct['full_story']);
		}
		///XXX
		if (is_object($content_struct['dateCreated'])){
			$dateCreatedUnix = $content_struct['dateCreated']->getTimestamp();
			$post_date = date("Y-m-d H:i:s", $dateCreatedUnix + $gmt_offset*3600);
		}
		$content_struct['newdate'] = $post_date;
		//mt_convert_breaks
		//mt_text_more
		//mt_excerpt
		//mt_tb_ping_urls
		$post_ID = addnews( $content_struct, $error );
		if ( $error )
			return new IXR_Error(500, $error);
		if (!$post_ID) {
			return new IXR_Error(500, __('Sorry, your entry could not be posted. Something wrong happened.'));
		}
		return strval($post_ID);
	}
	function mw_newMediaObject($args) {
		global $config;
		$blog_ID     = (int) $args[0];
		$username  = $args[1];
		$password   = $args[2];
		$data        = $args[3];
		$name = $data['name'];
		$type = $data['type'];
		$bits = $data['bits'];
		/*$fp = fopen('xmlrpc_media_log.txt', "w+");
		foreach($data as $item => $val){
			if (is_array($val)) $val = implode(",", $val);
			fwrite($fp, $item . ": " . $val . "\r\n");
		}
		fclose($fp);*/
		if ( !$user = $this->_login($username, $password) ) {
			return $this->error;
		}
		$file_path = addmedia($data, & $error);
		if ( $error )
			return new IXR_Error(500, $error);
		$url = rtrim($config['http_home_url'], '/') . $file_path;
		return array(
					'file' => $name,
					'url' => $url,
					'type' => $type
		);
	}
	function mw_editPost($args) {
		$post_ID     = (int) $args[0];
		$username  = $args[1];
		$password   = $args[2];
		$content_struct = $args[3];
		$publish     = $args[4];
		if ( !$user = $this->_login($username, $password) ) {
			return $this->error;
		}
		# bla bla
		return true;
	}
}
/*
allow_comm - разрешить комментарии
allow_main - публиковать на главной
approve - опубликовать новость на сайте
allow_rating - разрешить рейтинг статьи
news_fixed - зафиксировать новость
allow_br - автоматический перенос строк
title - заголовок
full_story - полное описание
short_story - краткое описание
alt_name - ЧПУ URL статьи
catalog_url - Символьный код
tags - теги
vote_title - заголовок опроса
frage - вопрос голосования
vote_body - варианты ответов
allow_m_vote - разрешить выбор нескольких вариантов в голосовании
group_extra - настройки доступа
expires - Срок действия до
expires_action - действие по истекании срока
allow_date - испоьзовать текущую дата
newdate - дата
category - массив id категорий
*/
function addnews($content_struct, & $error){
	global $user_group;
	global $member_id;
	global $config;
	global $db;
	global $allow_comm;
	global $allow_rating;
	$error = "";
	include_once ENGINE_DIR . '/classes/parse.class.php';
	$parse = new ParseFilter( Array (), Array (), 1, 1 );
	$allow_comm = $allow_comm ? 1 : 0;
	$allow_main = isset( $content_struct['allow_main'] ) ? intval( $content_struct['allow_main'] ) : 0;
	$approve = isset( $content_struct['approve'] ) ? intval( $content_struct['approve'] ) : 0;
	$allow_rating = $allow_rating ? 1 : 0;
	$news_fixed = isset( $content_struct['news_fixed'] ) ? intval( $content_struct['news_fixed'] ) : 0;
	$allow_br = isset( $content_struct['allow_br'] ) ? intval( $content_struct['allow_br'] ) : 0;
	if (!is_array($content_struct['group_extra'])){
		$content_struct['group_extra'][2] = 0;//главные редакторы
		$content_struct['group_extra'][3] = 0;//журналисты
		$content_struct['group_extra'][4] = 0;//посетители
		$content_struct['group_extra'][5] = 0;//гости
	}
	if (!$content_struct['newdate']) $content_struct['allow_date'] = 1;
	if( ! count( $content_struct['category'] ) || !is_array($content_struct['category']) ) {
		$content_struct['category'] = array ();
		$content_struct['category'][] = '0';
	}
	$category_list = $db->safesql( implode( ',', $content_struct['category'] ) );
	$allow_list = explode( ',', $user_group[$member_id['user_group']]['cat_add'] );
	foreach ( $content_struct['category'] as $selected ) {
		if( $allow_list[0] != "all" and ! in_array( $selected, $allow_list ) and $member_id['user_group'] != "1" ) $approve = 0;
	}
	$title = $parse->process(  trim( strip_tags ($content_struct['title']) ) );
	if ( $config['allow_admin_wysiwyg'] == "yes" ) $parse->allow_code = false;
	$full_story = $parse->process( $content_struct['full_story'] );
	$short_story = $parse->process( $content_struct['short_story'] );
	if( $config['allow_admin_wysiwyg'] == "yes" or $allow_br != '1' ) {
		$full_story = $db->safesql( $parse->BB_Parse( $full_story ) );
		$short_story = $db->safesql( $parse->BB_Parse( $short_story ) );
	} else {
		$full_story = $db->safesql( $parse->BB_Parse( $full_story, false ) );
		$short_story = $db->safesql( $parse->BB_Parse( $short_story, false ) );
	}
	$alt_name = $content_struct['alt_name'];
	if( trim( $alt_name ) == "" or ! $alt_name ) $alt_name = totranslit( stripslashes( $title ), true, false );
	else $alt_name = totranslit( stripslashes( $alt_name ), true, false );
	$title = $db->safesql( $title );
	$metatags = create_metatags( $short_story . $full_story );
	$catalog_url = $db->safesql( substr( htmlspecialchars( strip_tags( stripslashes( trim( $content_struct['catalog_url'] ) ) ) ), 0, 3 ) );
	if( preg_match( "/[\||\'|\<|\>|\"|\!|\?|\$|\@|\/|\\\|\&\~\*\+]/", $content_struct['tags'] ) ) $content_struct['tags'] = "";
	else $content_struct['tags'] = $db->safesql( htmlspecialchars( strip_tags( stripslashes( trim( $content_struct['tags'] ) ) ), ENT_QUOTES ) );
	// ��������� ������
	if( trim( $content_struct['vote_title'] != "" ) ) {
		$add_vote = 1;
		$vote_title = trim( $db->safesql( $parse->process( $content_struct['vote_title'] ) ) );
		$frage = trim( $db->safesql( $parse->process( $content_struct['frage'] ) ) );
		$vote_body = $db->safesql( $parse->BB_Parse( $parse->process( $content_struct['vote_body'] ), false ) );
		$allow_m_vote = intval( $content_struct['allow_m_vote'] );
	} else
		$add_vote = 0;
	// ��������� �������
	if( $member_id['user_group'] < 3 ) {
		$group_regel = array ();
		foreach ( $content_struct['group_extra'] as $key => $value ) {
			if( $value ) $group_regel[] = intval( $key ) . ':' . intval( $value );
		}
		if( count( $group_regel ) ) $group_regel = implode( "||", $group_regel );
		else $group_regel = "";
	} else
		$group_regel = '';
	if( trim( $content_struct['expires'] ) != "" ) {
		if( (($expires = strtotime( $content_struct['expires'] )) === - 1) ) {
			$error = __("Incorrect expires date");
			return false;
		}
	} else $expires = '';
	// ��������� ���� � �������
	$added_time = time() + ($config['date_adjust'] * 60);
	if( !$content_struct['allow_date'] ) {
		if( (($newsdate = strtotime( $content_struct['newdate'] )) === - 1) or (trim( $content_struct['newdate'] ) == "") ) {
			$error = __("Incorrect news date");
			return false;
		} else {
			$thistime = date( "Y-m-d H:i:s", $newsdate );
		}
		if( ! intval( $config['no_date'] ) and $newsdate > $added_time ) {
			$thistime = date( "Y-m-d H:i:s", $added_time );
		}
	} else
		$thistime = date( "Y-m-d H:i:s", $added_time );
		////////////////////////////
	if( trim( $title ) == "" or ! $title ) {
		$error = __("Type title");
		return false;
	}
	if( trim( $short_story ) == "" or ! $short_story ) {
		$error = __("Type short story");
		return false;
	}
	if( strlen( $title ) > 200 ) {
		$error = __("Max length of title 200 chars");
		return false;
	}
	$xfieldsid = $added_time;
	$xfieldsaction = "init";
	$category = $content_struct['category'];
	include (ENGINE_DIR . '/inc/xfields.php');
	$filecontents = array ();
	if( $config['safe_xfield'] ) {
		$parse->ParseFilter();
		$parse->safe_mode = true;
	}
	if( ! empty( $postedxfields ) ) {
		foreach ( $postedxfields as $xfielddataname => $xfielddatavalue ) {
			if( $xfielddatavalue == "" ) {
				continue;
			}
			$xfielddatavalue = $db->safesql( $parse->BB_Parse( $parse->process( $xfielddatavalue ), false ) );
			$xfielddataname = $db->safesql( $xfielddataname );
			$xfielddataname = str_replace( "|", "&#124;", $xfielddataname );
			$xfielddataname = str_replace( "\r\n", "__NEWL__", $xfielddataname );
			$xfielddatavalue = str_replace( "|", "&#124;", $xfielddatavalue );
			$xfielddatavalue = str_replace( "\r\n", "__NEWL__", $xfielddatavalue );
			$filecontents[] = "$xfielddataname|$xfielddatavalue";
		}
		$filecontents = implode( "||", $filecontents );
	} else
		$filecontents = '';
	$db->query( "INSERT INTO " . PREFIX . "_post (date, autor, short_story, full_story, xfields, title, descr, keywords, category, alt_name, allow_comm, approve, allow_main, fixed, allow_rate, allow_br, votes, access, symbol, flag, tags, metatitle) values ('$thistime', '{$member_id['name']}', '$short_story', '$full_story', '$filecontents', '$title', '', '{$metatags['keywords']}', '$category_list', '$alt_name', '$allow_comm', '$approve', '$allow_main', '$news_fixed', '$allow_rating', '$allow_br', '$add_vote', '$group_regel', '$catalog_url', '1', '{$content_struct['tags']}', '{$metatags['title']}')" );
	$row = $db->insert_id();
	if( $add_vote ) {
		$db->query( "INSERT INTO " . PREFIX . "_poll (news_id, title, frage, body, votes, multiple) VALUES('{$row}', '$vote_title', '$frage', '$vote_body', 0, '$allow_m_vote')" );
	}
	if( $expires ) {
		$expires_action = intval($content_struct['expires_action']);
		$db->query( "INSERT INTO " . PREFIX . "_post_log (news_id, expires, action) VALUES('{$row}', '$expires', '$expires_action')" );
	}
	if( $content_struct['tags'] != "" and $approve ) {
		$tags = array ();
		$content_struct['tags'] = explode( ",", $content_struct['tags'] );
		foreach ( $content_struct['tags'] as $value ) {
			$tags[] = "('" . $row . "', '" . trim( $value ) . "')";
		}
		$tags = implode( ", ", $tags );
		$db->query( "INSERT INTO " . PREFIX . "_tags (news_id, tag) VALUES " . $tags );
	}
	$db->query( "UPDATE " . PREFIX . "_images set news_id='{$row}' where author = '{$member_id['name']}' AND news_id = '0'" );
	$db->query( "UPDATE " . PREFIX . "_files set news_id='{$row}' where author = '{$member_id['name']}' AND news_id = '0'" );
	$db->query( "UPDATE " . USERPREFIX . "_users set news_num=news_num+1 where user_id='{$member_id['user_id']}'" );
	clear_cache();
	if (!$error){
		return $row;
	}
	return false;
}
function addmedia($data, & $error){
	global $config;
	global $user_group;
	global $member_id;
	global $db;
	$author = $member_id['name'];
	$allowed_files = explode( ',', strtolower( $config['files_type'] ) );
	define( 'FOLDER_PREFIX', date( "Y-m" ) );
	$action = "quick";
	if( $action == "quick" ) {
		$userdir = "posts/";
		if( ! is_dir( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX ) ) {
			@mkdir( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX, 0777 );
			@chmod( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX, 0777 );
			@mkdir( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX . "/thumbs", 0777 );
			@chmod( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX . "/thumbs", 0777 );
		}
		if( ! is_dir( ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX ) ) {
			$error = "Directory Error: " . "/uploads/posts/" . FOLDER_PREFIX . "/ cannot created." ;
			return false;
		}
		$config_path_image_upload = ROOT_DIR . "/uploads/posts/" . FOLDER_PREFIX . "/";
	}
	$file_prefix = time() + rand( 1, 100 );
	$file_prefix .= "_";
	//$imageurl = trim( htmlspecialchars( strip_tags( $_POST['imageurl'] ) ) );
	//$serverfile = trim( htmlspecialchars( strip_tags( $_POST['serverfile'] ) ) );
	//if( $serverfile != '' and ! @file_exists( ROOT_DIR . "/uploads/files/" . $serverfile ) ) $serverfile = '';
	/*if( $imageurl != "" ) {
		$urlcopy = "yes";
		$imageurl = str_replace( "\\", "/", $imageurl );
		$image_name = explode( "/", $imageurl );
		$image_name = end( $image_name );
		$img_name_arr = explode( ".", $image_name );
		$image_size = @filesize_url( $imageurl );
		$type = totranslit( end( $img_name_arr ) );
		if( $image_name != "" ) {
			$curr_key = key( $img_name_arr );
			unset( $img_name_arr[$curr_key] );
			$image_name = totranslit( implode( ".", $img_name_arr ) ) . "." . $type;
		}
	} else {*/
		$urlcopy = "";
		//$current_image = 'file_' . $image_i;
		//$image = $_FILES[$current_image]['tmp_name'];
		//$image_name = $_FILES[$current_image]['name'];
		$image_name = $data['name'];
		//$image_size = $_FILES[$current_image]['size'];
		$image_size = 0;
		$img_name_arr = explode( ".", $image_name );
		$type = totranslit( end( $img_name_arr ) );
		if( $image_name != "" ) {
			$curr_key = key( $img_name_arr );
			unset( $img_name_arr[$curr_key] );
			$image_name = totranslit( implode( ".", $img_name_arr ) ) . "." . $type;
		}
	//}
	if( $config['files_allow'] == "yes" and $user_group[$member_id['user_group']]['allow_file_upload'] and
			$action == "quick" and (in_array( strtolower( $type ), $allowed_files ) or $serverfile != '') ) {
		//if( $serverfile == '' ) {
			if( $urlcopy != "yes" ){
				$fp = fopen(ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name, "w+");
				$result = fwrite($fp, $data['bits']);
				fclose($fp);
				if (!$result){
					$error = "Can't write file";
					return false;
				}
				//@move_uploaded_file( $image, ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name );
			}
			/*else{
				@copy( $imageurl, ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name ) or $img_result = "<div><font color=red>$lang[images_uperr_3]</font></div>";
			}*/
		/*} else {
			$file_prefix = '';
			$image_name = $serverfile;
		}*/
		if( @file_exists( ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name ) ) {
			if( intval( $config['max_file_size'] ) and
					@filesize( ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name ) > ($config['max_file_size'] * 1024) ) {
				@unlink( ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name );
				$error = "File too big";
				return false;
				//$img_result .= "<div><font color=red>$image_name -> $lang[files_too_big]</font></div>";
			} else {
				@chmod( ROOT_DIR . "/uploads/files/" . $file_prefix . $image_name, 0666 );
				//$img_result .= "<div><font color=green>$image_name -> $lang[files_upok]</font></div>";
				$added_time = time() + ($config['date_adjust'] * 60);
				#TODO::
				if( $area == "template" ) {
					$db->query( "INSERT INTO " . PREFIX . "_static_files (static_id, author, date, name, onserver) values ('$news_id', '$author', '$added_time', '$image_name', '{$file_prefix}{$image_name}')" );
				} else {
					$db->query( "INSERT INTO " . PREFIX . "_files (news_id, name, onserver, author, date) values ('$news_id', '$image_name', '{$file_prefix}{$image_name}', '$author', '$added_time')" );
				}
			}
			$file_path = "/uploads/files/" . $file_prefix . $image_name;
		}
	#TODO::
	//} elseif( $image_name == "" ) {
	//	$img_result .= "<div><font color=red>$current_image -> $lang[images_uperr]</font></div>";
	//} elseif( ! isset( $overwrite ) and file_exists( $config_path_image_upload . $image_name ) ) {
	//	$img_result .= "<div><font color=red>$current_image -> $lang[images_uperr_1]</font></div>";
	//} elseif( ! (in_array( $type, $allowed_extensions ) or in_array( strtolower( $type ), $allowed_extensions )) ) {
	//	$img_result .= "<div><font color=red>$current_image -> $lang[images_uperr_2]</font></div>";
	//} elseif( $image_size > ($config['max_up_size'] * 1024) and ! $config['max_up_side'] ) {
	//	$img_result .= "<div><font color=red>$current_image -> $lang[images_big]</font></div>";
	} else {
		if( $urlcopy != "yes" ){
			$fp = fopen($config_path_image_upload . $file_prefix . $image_name, "w+");
			$result = fwrite($fp, $data['bits']);
			fclose($fp);
			if (!$result){
				$error = "Can't write file";
				return false;
			}
			//@move_uploaded_file( $image, $config_path_image_upload . $file_prefix . $image_name ) or $img_result = "<div><font color=red>$lang[images_uperr_3]</font></div>";
		}
		//else{
		//	@copy( $imageurl, $config_path_image_upload . $file_prefix . $image_name ) or $img_result = "<div><font color=red>$lang[images_uperr_3]</font></div>";
		//}
		if( @file_exists( $config_path_image_upload . $file_prefix . $image_name ) ) {
			@chmod( $config_path_image_upload . $file_prefix . $image_name, 0666 );
			//$img_result .= "<div><font color=green>$image_name -> $lang[images_upok]</font></div>";
			if( $action == "quick" and $area != "template" ) {
				#TODO::
				$row = $db->super_query( "SELECT COUNT(*) as count FROM " . PREFIX . "_images where author = '$author' AND news_id = '$news_id'" );
				if( ! $row['count'] ) {
					$added_time = time() + ($config['date_adjust'] * 60);
					$inserts = FOLDER_PREFIX . "/" . $file_prefix . $image_name;
					$db->query( "INSERT INTO " . PREFIX . "_images (images, author, news_id, date) values ('$inserts', '$author', '$news_id', '$added_time')" );
				} else {
					$row = $db->super_query( "SELECT images  FROM " . PREFIX . "_images where author = '$author' AND news_id = '$news_id'" );
					if( $row['images'] == "" ) $listimages = array ();
					else $listimages = explode( "|||", $row['images'] );
					foreach ( $listimages as $dataimages ) {
						if( $dataimages == FOLDER_PREFIX . "/" . $file_prefix . $image_name ) $error_image = "stop";
					}
					if( $error_image != "stop" ) {
						$listimages[] = FOLDER_PREFIX . "/" . $file_prefix . $image_name;
						$row['images'] = implode( "|||", $listimages );
						$db->query( "UPDATE " . PREFIX . "_images set images='{$row['images']}' where author = '$author' AND news_id = '$news_id'" );
					}
				}
			}
			#TODO::
			if( $area == "template" and $action == "quick" ) {
				$added_time = time() + ($config['date_adjust'] * 60);
				$inserts = FOLDER_PREFIX . "/" . $file_prefix . $image_name;
				$db->query( "INSERT INTO " . PREFIX . "_static_files (static_id, author, date, name) values ('$news_id', '$author', '$added_time', '$inserts')" );
			}
			include_once ENGINE_DIR . '/classes/thumb.class.php';
			if( $member_id['user_group'] > 3 ) {
				$data['make_thumb'] = true;
				$data['make_watermark'] = $config['allow_watermark'];
			}
			if( isset( $data['make_thumb'] ) ) {
				$thumb = new thumbnail( $config_path_image_upload . $file_prefix . $image_name );
				if( $thumb->size_auto( $config['max_image'], $data['t_seite'] ) ) {
					$thumb->jpeg_quality( $config['jpeg_quality'] );
					if( $config['allow_watermark'] == "yes" and $data['make_watermark'] == "yes" ) $thumb->insert_watermark( $config['max_watermark'] );
					$thumb->save( $config_path_image_upload . "thumbs/" . $file_prefix . $image_name );
				}
				//if( @file_exists( $config_path_image_upload . "thumbs/" . $file_prefix . $image_name ) ) $img_result_th .= "<div><font color=blue>$image_name -> $lang[images_thok]</font></div>";
				@chmod( $config_path_image_upload . "thumbs/" . $file_prefix . $image_name, 0666 );
			}
			$config['max_up_side'] = intval( $config['max_up_side'] );
			if( ($config['allow_watermark'] == "yes" and $data['make_watermark'] == "yes") or $config['max_up_side'] ) {
				$thumb = new thumbnail( $config_path_image_upload . $file_prefix . $image_name );
				$thumb->jpeg_quality( $config['jpeg_quality'] );
				if( $config['max_up_side'] ) $thumb->size_auto( $config['max_up_side'] );
				if( $config['allow_watermark'] == "yes" and $data['make_watermark'] == "yes" ) $thumb->insert_watermark( $config['max_watermark'] );
				$thumb->save( $config_path_image_upload . $file_prefix . $image_name );
			}
			$file_path = "/uploads/posts/" . FOLDER_PREFIX . "/" . $file_prefix . $image_name;
		} //if file is uploaded succesfully
		//if( $urlcopy == "yes" or $serverfile != '' ) break;
	}
	//}
	if(!$error){
		return $file_path;
	}
	return false;
}
$server = new dle_xmlrpc_server();
?>
