<?php
class Bazzinga {
	protected $min_words = 5; /*  Сколько слов минимум требует синонимайзинг          */
	protected $max_chars = 10000; /*  Сколько максимум символов в одном синонимайзинге    */
	protected $useragent = 'Bazzingoid 1/2'; /*  Агент Баззинги                                      */
	protected $mainhref = 'http://bazzinga.org/'; /*  Главный урл Баззинги                                */
	private $logged_in = false;
	private $sid = false;
	private $settings = array(

	'highlight' => 0,      /*  Подсвечивать ли выдачу              */
                                    'login' => false,  /*  Логин                               */
                                    'password' => false,  /*  Пароль                              */
                                    'cookie_file' => false,  /*  Если надо - файл, где хранить куку.
                                                                    Если не false и есть файл - то
                                                                    куки-стринг игнорируется            */

                                    'ip' => false,  /*  Если надо - интерфейс               */
                                    'charset' => false   /*  Если надо - оригинальная кодировка  */

                                );
	
	function __construct($params = array()) {
		
		setlocale(E_ALL, 'ru_RU.UTF8');
		
		try {
			if (!is_array($params)) {
				$this->setError('Конструктор класса при создании требует массив, а не всякое там.', __LINE__);
			}
			foreach($params as $k => $v) {
				if (isset($this->settings[$k])) {
					$this->settings[$k] = $v;
				}
			}
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setLogin($string = false) {
		try {
			if (!$string) {return;}
			if (!preg_match('|^[\w\d]+$|', $string)) {
				$this->setError('Неверный вид логина', __LINE__);
			}
			$this->settings['login'] = $string;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setPassword($string = false) {
		try {
			if (!$string) {return;}
			if (!preg_match('|^[\w\d[:punct:]]+$|', $string)) {
				$this->setError('Неверный вид пароля', __LINE__);
			}
			$this->settings['password'] = $string;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setIP($string = false) {
		try {
			if (!$string) {return;}
			if (!preg_match('|^(\d{1,3}\.){3}\d{1,3}$|', $string)) {
				$this->setError('Неверный вид интерфейса', __LINE__);
			}
			$this->settings['ip'] = $string;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setHighlight($string = 0) {
		try {
			if (!$string) {return;}
			if ($string != 1) {
				$this->setError('Неверный вид параметра подсветки', __LINE__);
			}
			$this->settings['highlight'] = 1;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setCharset($string = 0) {
		try {
			if (!$string) {return;}
			if (!preg_match('|^[a-z\d\-]+$|i', $string)) {
				$this->setError('Неверный вид кодировки', __LINE__);
			}
			$this->settings['charset'] = $string;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function setCookieFile($string = 0) {
		try {
			if (!$string) {return;}
			$cookie_dir = preg_replace('|\/[^\/]+$|', '', $string);
			
			if (!file_exists($string) || !is_writable($string) || !is_writable($cookie_dir)) {
				$this->setError('Файл ' . $string . ' или директория ' . $cookie_dir . ' недоступны для записи', __LINE__);
			}
			$this->settings['cookie_file'] = $string;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function uniqueText($text = '') {
		if (!$this->logged_in) {
			$this->LogIn();
		}
		try {
			if (!$text) {
				$this->setError('Нет текста', __LINE__);
			}
			$notags = strlen(preg_replace('|<[^>]+>|sm', '', $text));
			
			if ($notags > $this->max_chars) {
				$this->setError('Превышено допустимое количество символов (' . $this->max_chars . ') - ' . $notags, __LINE__);
			}
			$wordscount = count(preg_split("/\s+/", $text, 41));
			if ($wordscount < $this->min_words) {
				$this->setError('Не хватает слов - надо не меньше ' . $this->min_words, __LINE__);
			}
			
			if ($this->settings['charset'] && !preg_match('|^utf\-?8$|i', $this->settings['charset'])) {
				$text = iconv($this->settings['charset'], "UTF-8//IGNORE", $text);
			}
			$md5_check = md5(base64_encode(preg_replace('|[\s\t\r\n]|', '', $text)));
			$text = urlencode($text);
			$result = $this->_getURL(array('href' => $this->mainhref . 'magic.html', 'cookie_string' => $this->sid, 'post' => 'input=' . $text . '&highlight=' . $this->settings['highlight'] . '&inputmd5=' . $md5_check));
			if (strpos($result, 'http://bazzinga.org/api.html') !== false) {
				$this->logged_in = false;
				$this->setError('Вероятно, ошибка авторизации - "' . $result . '"', __LINE__);
			}
			return $result;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	public function LogIn() {
		
		$key = $this->getKey();
		try {
			if (!$this->settings['login']) {
				$this->setError('Нужен логин!', __LINE__);
			}
			if (!$this->settings['password']) {
				$this->setError('Нужен пароль!', __LINE__);
			}
			$result = $this->_getURL(array('href' => $this->mainhref . 'inc/auth.php', 'cookie_string' => $this->sid, 'post' => 'login=' . $this->settings['login'] . '&pass=' . md5(md5($this->settings['password']) . $key)));
			$this->logged_in = true;
		} catch (Exception $e) {
			$this->showError($e);
		}
	
	}
	
	private function getKey() {
		
		$result = $this->_getURL(array('href' => $this->mainhref . 'inc/keys.php', 'header' => 1));
		try {
			if (!$result) {
				$this->setError('Не удалось получить ключ.', __LINE__);
			}
			
			preg_match('/^Set-Cookie: (.*?);/mi', $result, $cookie);
			preg_match('|<key>([^<]+)|i', $result, $key);
			if (!$cookie[1] && !$this->settings['cookie_file']) {
				$this->setError('Не удалось получить cookie для ключа', __LINE__);
			}
			if (!$key[1]) {
				$this->setError('Не удалось получить ключ из контента', __LINE__);
			}
			if (!$this->settings['cookie_file']) {
				$this->sid = $cookie[1];
			}
			return $key[1];
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	private function _getURL($params = array()) {
		
		try {
			if (!isset($params['href'])) {
				$this->setError('Для этого метода нужно значение ключа href', __LINE__);
			}
			$params['header'] = $params['header'] == 1 ? 1 : 0;
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $params['href']);
			curl_setopt($ch, CURLOPT_USERAGENT, $this->useragent);
			
			if ($params['post']) {
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $params['post']);
			}
			
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HEADER, $params['header']);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			
			if ($this->settings['ip']) {
				curl_setopt($ch, CURLOPT_INTERFACE, $this->settings['ip']);
			}
			
			if ($this->settings['cookie_file']) {
				curl_setopt($ch, CURLOPT_COOKIEFILE, $this->settings['cookie_file']);
				curl_setopt($ch, CURLOPT_COOKIEJAR, $this->settings['cookie_file']);
			} elseif ($params['cookie_string']) {
				curl_setopt($ch, CURLOPT_COOKIE, $params['cookie_string']);
			}
			
			$result = curl_exec($ch);
			
			if ($result === false) {
				$this->setError('Ошибка запроса - ' . curl_error($ch), __LINE__);
			}
			
			$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			
			curl_close($ch);
			
			if ($http_code != 200) {
				$this->setError('HTTP-код запроса адреса ' . $params['href'] . ' не 200 (' . $http_code . ')', __LINE__);
			}
			return $result;
		} catch (Exception $e) {
			$this->showError($e);
		}
	}
	
	private function setError($e, $l = 0) {
		throw new Exception('[Line ' . $l . '] ' . $e);
	}
	
	private function showError($e) {
		echo 'E: ', $e->getMessage(), "\n";
	}

}
//$bzz = new Bazzinga(array('login' => 'webavangard', 'password' => 'pass', 'cookie_file' => '/tmp/bz.cookie'));
//
//var_dump($bzz->uniqueText('Может показаться, что Bazzinga - это просто бесплатный онлайн синонимайзер, однако истина состоит в другом. Bazzinga - это первый динозавр, умеющий читать и писать по-русски. Правда, пока что Bazzinga еще очень маленькая, ей требуется много внимания и заботы. Именно поэтому мы каждый день стараемся пополнять ее словарный запас и учить ее новым трюкам.'));
