<?
define('USERNAME', 'Логин'); // Ваш логин на bazzinga.org
define('PASSWORD', 'pass'); // Ваш пароль для доступа к bazzinga.org
define('GZIP', 'false'); // Использовать сжатие данных (нужна поддержка zlib): false/true
define('GZIPLVL', '9'); // Уровень сжатия данных (от 0 до 9)
define('HIGHLIGHTING', 'false'); // Подсвечивать фон в измененных участках текста: false/true
define('SEO_OPT', 'false'); // Дополнительная обработка через базу SEO: false/true
define('SLANG_OPT', 'false'); // Дополнтельная обработка через базу жаргонизмов: false/true
define('USR_OPT', 'false'); // Дополнительная обработка через Вашу личную базу на Баззинге. Прежде чем включать эту опцию, необходимо создать личную базу на странице http://bazzinga.org/profile.html


define('agent', 'Bazzingoid 1/3');

$str = 'Может показаться, что Bazzinga - это просто бесплатный онлайн синонимайзер, однако истина состоит в другом. Bazzinga - это первый динозавр, умеющий читать и писать по-русски. Правда, пока что Bazzinga еще очень маленькая, ей требуется много внимания и заботы. Именно поэтому мы каждый день стараемся пополнять ее словарный запас и учить ее новым трюкам.';
echo bazzinga($str);
echo "\n<br>Осталось запросов: " . bazzinga('limit_request');

////////////////////////////////////////////////////////////////////////////////////
// НИЖЕ ЭТОЙ СТРОКИ НИЧЕГО НЕ ТРОГАЙТЕ. Я СЕРЬЕЗНО. //
////////////////////////////////////////////////////////////////////////////////////


function bazzinga($str) {
	$predata = get_key();
	$session_id = $predata[0];
	$key = $predata[1];
	$mydata = 'login=' . USERNAME . '&pass=' . md5(md5(PASSWORD) . $key) . '';
	auth_me($mydata, $session_id);
	$result = stripslashes(uniqme($session_id, $str));
	logout($session_id);
	return $result;
}

function logout($sid) {
	$logouturl = "http://bazzinga.org/logout.html?hidestatus=true";
	$sid = 'PHPSESSID=' . $sid . '; path=/';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $logouturl);
	curl_setopt($ch, CURLOPT_USERAGENT, agent);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_COOKIE, $sid);
	curl_exec($ch);
	curl_close($ch);
}

function uniqme($session_id, $input) {
	$magicurl = "http://bazzinga.org/magic.html";
	$inputmd5 = md5(base64_encode(preg_replace('|[\s\t\r\n]|', '', $input)));
	$input = urlencode($input);
	if (GZIP == "true") {
		$input = strtr(base64_encode(gzcompress($input, GZIPLVL)), '+/=', '-_,');
	}
	$str = 'input=' . $input . '&gzip=' . GZIP . '&gziplvl=' . GZIPLVL . '&inputmd5=' . $inputmd5 . '&highlight=' . HIGHLIGHTING . '&seo_opt=' . SEO_OPT . '&slang_opt=' . SLANG_OPT . '&usr_opt=' . USR_OPT . '';
	$session_id = 'PHPSESSID=' . $session_id . '; path=/';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $magicurl);
	curl_setopt($ch, CURLOPT_USERAGENT, agent);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $str);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_COOKIE, $session_id);
	$data = curl_exec($ch);
	if (GZIP == "true") {
		$data = gzuncompress(base64_decode(strtr($data, '-_,', '+/=')));
	}
	curl_close($ch);
	return urldecode($data);
}

function auth_me($data, $sid) {
	$authurl = "http://bazzinga.org/inc/auth.php";
	$sid = 'PHPSESSID=' . $sid . '; path=/';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $authurl);
	curl_setopt($ch, CURLOPT_USERAGENT, agent);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_COOKIE, $sid);
	curl_exec($ch);
	curl_close($ch);
}

function get_key() {
	$url = "http://bazzinga.org/inc/keys.php";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_USERAGENT, agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_VERBOSE, false);
	curl_setopt($ch, CURLOPT_TIMEOUT, 5);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	$data = curl_exec($ch);
	$session = preg_match("/PHPSESSID=(.*);/", $data, $smatch);
	$key = preg_match("/([a-z0-9]+)<\/key>/", $data, $kmatch);
	curl_close($ch);
	return array($smatch[1], $kmatch[1]);
}

?>