<?php
// encoding UTF-8
define('USERNAME', 'webavangard'); // Ваш логин на bazzinga.org
define('PASSWORD', 'd9e7aac'); // Ваш пароль для доступа к bazzinga.org
define('HIGHLIGHTING', 'false'); // Подсвечивать фон в измененных участках текста: false/true
define('COOKIE_FILE', 'cookie.txt'); // файл с кукисами

// функция которой обработаем время
function getmicrotime() {
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

$data = $HTTP_RAW_POST_DATA; // получаем данные переданные скрипту из FeedMaster
$data = json_decode($data, true); // декодируем
$text = $data['data']; // получаем непосредственно текст для перевода

$start = getmicrotime(); // засечем время работы

require_once 'Bazzinga.php'; // подключаем клас Bazzinga

// создаем объект Bazzinga и указываем настройки
$bzz = new Bazzinga(array('login' => USERNAME, 'password' => PASSWORD, 'highlight' => HIGHLIGHTING, 'cookie_file'=> COOKIE_FILE));

// переводим через сервис Bazzinga
$return['result'] = $bzz->uniqueText($text); // (выведет командой userplugin ^result)
$return['orig'] = $text; // также к результату добавим оригинал статьи (выведет командой userplugin ^orig)

$time = getmicrotime() - $start; // засечем время работы
$return['time'] = $time; // также к результату добавим время рвботы (выведет командой userplugin ^time)


echo json_encode($return); // возвращаем (закодированный!) результат FeedMaster

